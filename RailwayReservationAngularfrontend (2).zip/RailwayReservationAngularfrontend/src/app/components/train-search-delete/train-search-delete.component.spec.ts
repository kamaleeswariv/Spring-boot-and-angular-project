import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainSearchDeleteComponent } from './train-search-delete.component';

describe('TrainSearchDeleteComponent', () => {
  let component: TrainSearchDeleteComponent;
  let fixture: ComponentFixture<TrainSearchDeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainSearchDeleteComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainSearchDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
