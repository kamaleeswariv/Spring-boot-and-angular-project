import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TrainRegistrationService } from 'src/app/TrainRegistrationService';

@Component({
  selector: 'app-train-search-delete',
  templateUrl: './train-search-delete.component.html',
  styleUrls: ['./train-search-delete.component.css']
})
export class TrainSearchDeleteComponent {
  trains: any;
  trainId: any;
  trainName:any;
  

constructor(private service:TrainRegistrationService, private router:Router ){}
  ngOnInit(){
    let resp=this.service.getTrains();
    resp.subscribe((data)=>this.trains=data);
  }

  
    public getTrainById(trainId:number){
      let resp=this.service.getTrainById(trainId);
      resp.subscribe((data)=>this.trains=data);
    }

  
   
      public updateTrain(trainId:number){
        this.router.navigate(['updateTrain',trainId])
      }
      public deleteTrain(trainId:number){
        if(!confirm("Are you sure you want to delete?")) return;
        let resp=this.service.deleteTrain(this.trainId);
        resp.subscribe((data)=>this.trains=data);
        }
        public getTrainByName(trainName:string){
          let resp=this.service.getTrainByName(this.trainName);
          resp.subscribe((data)=>this.trains=data);
        }
      
}




