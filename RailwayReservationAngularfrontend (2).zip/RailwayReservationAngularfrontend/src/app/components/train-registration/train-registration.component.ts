import { Component, OnInit } from '@angular/core';
import { Train } from 'src/app/entity/train';
import { TrainRegistrationService } from 'src/app/TrainRegistrationService';

@Component({
  selector: 'app-train-registration',
  templateUrl: './train-registration.component.html',
  styleUrls: ['./train-registration.component.css']
})
export class TrainRegistrationComponent implements OnInit {
  trains:Train=new Train("","", "","",0,0);
  message:any;
  ngOnInit(): void {              
  
  }
constructor(private service:TrainRegistrationService){}
public registerNow(){
  //need to call doregisteration from service
  console.log("registernow");
  let resp=this.service.registerNow(this.trains);
  resp.subscribe((data: any)=>this.message=data);

}
}
