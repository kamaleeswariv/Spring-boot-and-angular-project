import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { UserRegistraionComponent } from './components/user-registraion/user-registraion.component';
import { SearchDeleteComponent } from './components/user-search-delete/search-delete.component';
import { FormsModule } from '@angular/forms';
import { TrainRegistrationComponent } from './components/train-registration/train-registration.component';
import { UserRegistraionService } from './UserRegistraionService';
import { TrainRegistrationService } from './TrainRegistrationService';
import { TrainSearchDeleteComponent } from './components/train-search-delete/train-search-delete.component';
import { TrainUpdateComponent } from './components/train-update/train-update.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TrainSearchDeleteComponent,
    UserRegistraionComponent,
    SearchDeleteComponent,
    
    TrainRegistrationComponent,
    TrainUpdateComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [UserRegistraionService,
    TrainRegistrationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
