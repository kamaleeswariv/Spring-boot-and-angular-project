import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { SearchDeleteComponent } from './components/user-search-delete/search-delete.component';
import { TrainRegistrationComponent } from './components/train-registration/train-registration.component';
//import { TrainRegistrationComponent } from './components/train-registration/train-registration.component';
import { UserRegistraionComponent } from './components/user-registraion/user-registraion.component';
import { TrainSearchDeleteComponent } from './components/train-search-delete/train-search-delete.component';

const routes: Routes = [
  {path:"",redirectTo:"home",pathMatch:"full"},
  {path:"home",component:HomeComponent},
  {path:"register",component:UserRegistraionComponent},
  {path:"search",component:SearchDeleteComponent},
  {path:"train-register",component:TrainRegistrationComponent},
  {path:"train-search-delete",component:TrainSearchDeleteComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
